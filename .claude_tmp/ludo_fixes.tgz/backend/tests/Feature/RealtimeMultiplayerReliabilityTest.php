<?php

namespace Tests\Feature;

use App\Events\DiceRolled;
use App\Events\GameEnded;
use App\Events\PlayerDisconnected;
use App\Events\PlayerReconnected;
use App\Events\TokenMoved;
use App\Events\TurnChanged;
use App\Models\MatchEvent;
use App\Models\MatchState;
use App\Models\Matchup;
use App\Models\SocialAccount;
use App\Models\User;
use App\Services\Game\GameEngineService;
use App\Services\RoomService;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use Tests\TestCase;

/**
 * Reliability guarantees behind the real-multiplayer dice/token fix.
 *
 * These prove the two changes that make real online matches behave like bot
 * matches (which never touch the server at all):
 *
 *   1. Every in-game event is delivered IMMEDIATELY (ShouldBroadcastNow), so a
 *      missing / slow / backed-up `queue:work` worker can no longer strand
 *      opponents on the 2s recovery poll.
 *   2. Every broadcast carries the authoritative post-commit state revision
 *      (`seq`), so a client can order events and resync to an exact revision.
 *
 * ...and that all of it is identical for every login pairing (two Facebook,
 * Facebook↔Google, Facebook↔guest, Google↔guest).
 */
class RealtimeMultiplayerReliabilityTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Event::fake();
    }

    /** Create a user authenticated the given way (guest / facebook / google). */
    private function userFor(string $provider): User
    {
        if ($provider === 'guest') {
            return User::factory()->guest()->create();
        }

        $user = User::factory()->create();
        SocialAccount::create([
            'user_id' => $user->id,
            'provider' => $provider,
            'provider_user_id' => "{$provider}-".$user->id,
        ]);

        return $user;
    }

    /** Start a 2p match between two users and return it (players loaded). */
    private function startMatch(User $a, User $b): Matchup
    {
        $rooms = app(RoomService::class);
        $room = $rooms->create($a, ['mode' => '2p', 'visibility' => 'private']);
        $rooms->join($room, $b);
        $rooms->setReady($room, $a, true);
        $rooms->setReady($room, $b, true);
        $match = $rooms->start($room);
        $match->load('players');

        return $match;
    }

    private function colorOf(User $user, Matchup $match): string
    {
        return $match->players->firstWhere('user_id', $user->id)->color;
    }

    /** Put $color into awaiting_roll with token 0 on ring cell 10 (movable by any dice). */
    private function stageAwaitingRoll(Matchup $match, string $color, string $opponent): void
    {
        $row = MatchState::where('match_id', $match->id)->first();
        $row->state = array_replace($row->state, [
            'turn' => $color,
            'phase' => 'awaiting_roll',
            'dice' => null,
            'consecutive_sixes' => 0,
            'tokens' => [
                $color => [10, -1, -1, -1],
                $opponent => [-1, -1, -1, -1],
            ],
        ]);
        $row->save();
    }

    /**
     * The four login pairings the reporter cares about — every one must drive an
     * identical, complete roll → move cycle over HTTP.
     *
     * @return array<string,array{0:string,1:string}>
     */
    public static function loginPairings(): array
    {
        return [
            'facebook vs facebook' => ['facebook', 'facebook'],
            'facebook vs google' => ['facebook', 'google'],
            'facebook vs guest' => ['facebook', 'guest'],
            'google vs guest' => ['google', 'guest'],
        ];
    }

    /**
     * @dataProvider loginPairings
     */
    public function test_every_login_pairing_completes_one_tap_roll_and_move(string $providerA, string $providerB): void
    {
        $player = $this->userFor($providerA);
        $opponent = $this->userFor($providerB);
        $match = $this->startMatch($player, $opponent);
        $color = $this->colorOf($player, $match);
        $other = $this->colorOf($opponent, $match);

        $this->stageAwaitingRoll($match, $color, $other);

        // One tap → exactly one authoritative roll. Token 0 is on cell 10, so
        // EVERY dice value 1..6 has a legal move — the player always enters
        // token selection, never a bogus "roll again".
        $roll = $this->actingAs($player)
            ->postJson("/api/v1/matches/{$match->id}/roll", [
                'color' => $color,
                'action_id' => "roll-{$providerA}-{$providerB}",
            ])
            ->assertOk()
            ->json('data');

        $dice = $roll['dice'];
        $this->assertIsInt($dice);
        $this->assertGreaterThanOrEqual(1, $dice);
        $this->assertLessThanOrEqual(6, $dice);
        $this->assertFalse($roll['forfeited']);
        $this->assertFalse($roll['turn_passed']);
        $this->assertSame('awaiting_move', $roll['state']['phase']);
        $this->assertNotEmpty($roll['legal_moves']);
        $this->assertSame(
            1,
            MatchEvent::where('match_id', $match->id)->where('type', 'dice_rolled')->count(),
        );

        // One tap → exactly one move of exactly `dice` steps, and it stays there.
        $move = $this->actingAs($player)
            ->postJson("/api/v1/matches/{$match->id}/move", [
                'color' => $color,
                'token' => 0,
                'action_id' => "move-{$providerA}-{$providerB}",
                'seq' => $roll['state']['seq'] + 1,
            ])
            ->assertOk()
            ->json('data');

        $this->assertSame(10, $move['from']);
        $this->assertSame(10 + $dice, $move['to']);
        $this->assertSame(range(11, 10 + $dice), $move['path']);
        $this->assertSame(
            10 + $dice,
            MatchState::where('match_id', $match->id)->first()->state['tokens'][$color][0],
            'the token lands exactly dice steps ahead and stays there',
        );
        $this->assertSame(
            1,
            MatchEvent::where('match_id', $match->id)->where('type', 'token_moved')->count(),
        );
        $this->assertSame($dice === 6, $move['extra_turn']);
        $this->assertSame($dice !== 6, $move['turn_passed']);
    }

    public function test_in_game_events_are_delivered_immediately_not_via_the_queue(): void
    {
        // ShouldBroadcastNow => `broadcast()` sends inline (after our post-commit
        // flush) instead of enqueuing a job. This is the fix for "the opponent's
        // dice/move is late / never arrives" when no queue worker is running.
        $immediate = [
            DiceRolled::class,
            TokenMoved::class,
            TurnChanged::class,
            GameEnded::class,
            PlayerReconnected::class,
            PlayerDisconnected::class,
        ];

        foreach ($immediate as $event) {
            $this->assertContains(
                ShouldBroadcastNow::class,
                class_implements($event),
                "{$event} must broadcast immediately (ShouldBroadcastNow).",
            );
        }
    }

    public function test_roll_broadcast_carries_the_committed_state_revision(): void
    {
        $player = $this->userFor('facebook');
        $opponent = $this->userFor('facebook');
        $match = $this->startMatch($player, $opponent);
        $color = $this->colorOf($player, $match);
        $other = $this->colorOf($opponent, $match);
        $this->stageAwaitingRoll($match, $color, $other);

        $result = app(GameEngineService::class)
            ->roll($match, $color, forcedDice: 3, actionId: 'rev-roll');

        $expected = (int) $result['state']['seq'];
        Event::assertDispatched(
            DiceRolled::class,
            fn (DiceRolled $e) => $e->revision === $expected,
        );
    }

    public function test_move_broadcasts_carry_the_committed_state_revision(): void
    {
        $player = $this->userFor('google');
        $opponent = $this->userFor('guest');
        $match = $this->startMatch($player, $opponent);
        $color = $this->colorOf($player, $match);
        $other = $this->colorOf($opponent, $match);
        $this->stageAwaitingRoll($match, $color, $other);

        $engine = app(GameEngineService::class);
        $engine->roll($match, $color, forcedDice: 3, actionId: 'rev-roll');
        $moveResult = $engine->move($match, $color, 0, actionId: 'rev-move');

        $finalSeq = (int) $moveResult['state']['seq'];
        $moveSeq = (int) $moveResult['move_seq'];

        // The token_moved carries BOTH the final state revision (for ordering)
        // and its own event seq (for de-duplicating the walk animation).
        Event::assertDispatched(
            TokenMoved::class,
            fn (TokenMoved $e) => $e->revision === $finalSeq && $e->sequence === $moveSeq,
        );
        // A non-six move (dice 3) passes the turn, so the turn change rides the
        // same final revision.
        Event::assertDispatched(
            TurnChanged::class,
            fn (TurnChanged $e) => $e->revision === $finalSeq,
        );
    }

    public function test_broadcast_payloads_expose_the_revision_field(): void
    {
        $dice = new DiceRolled(7, 'red', 4);
        $dice->revision = 42;
        $this->assertSame(42, $dice->broadcastWith()['revision']);

        $moved = new TokenMoved(7, 'red', 0, 10, 13, [11, 12, 13], [], 5);
        $moved->revision = 43;
        $this->assertSame(43, $moved->broadcastWith()['revision']);
        $this->assertSame(5, $moved->broadcastWith()['move_seq']);

        $turn = new TurnChanged(7, 'yellow');
        $turn->revision = 44;
        $this->assertSame(44, $turn->broadcastWith()['revision']);
    }

    public function test_state_endpoint_lets_a_player_who_missed_the_broadcast_resync_mid_turn(): void
    {
        // Simulates a reconnect / dropped Reverb event during the roll: the
        // roller commits a dice, then BOTH participants read GET /state and must
        // see the pending dice + its legal moves, so the board is rebuildable
        // with no lost turn (the recovery path that replaces missed events).
        $player = $this->userFor('facebook');
        $opponent = $this->userFor('guest');
        $match = $this->startMatch($player, $opponent);
        $color = $this->colorOf($player, $match);
        $other = $this->colorOf($opponent, $match);
        $this->stageAwaitingRoll($match, $color, $other);

        app(GameEngineService::class)->roll($match, $color, forcedDice: 4, actionId: 'resync-roll');

        foreach ([$player, $opponent] as $viewer) {
            $data = $this->actingAs($viewer)
                ->getJson("/api/v1/matches/{$match->id}/state")
                ->assertOk()
                ->json('data');

            $this->assertSame('awaiting_move', $data['state']['phase']);
            $this->assertSame(4, $data['state']['dice']);
            $this->assertSame($color, $data['state']['turn']);
            $this->assertIsInt($data['state']['seq']);
            $this->assertNotEmpty($data['legal_moves']);
            $this->assertSame(0, $data['legal_moves'][0]['token']);
        }
    }

    public function test_out_of_order_move_seq_is_rejected(): void
    {
        // The client asserts its expected next seq on every move. A stale/replayed
        // request carrying the wrong seq must be rejected (in addition to the
        // unique(match_id, seq) DB guard) so it can never apply out of order.
        $player = $this->userFor('facebook');
        $opponent = $this->userFor('facebook');
        $match = $this->startMatch($player, $opponent);
        $color = $this->colorOf($player, $match);
        $other = $this->colorOf($opponent, $match);
        $this->stageAwaitingRoll($match, $color, $other);

        $roll = $this->actingAs($player)
            ->postJson("/api/v1/matches/{$match->id}/roll", ['color' => $color, 'action_id' => 'ooo-roll'])
            ->assertOk()
            ->json('data');

        $expectedSeq = $roll['state']['seq'] + 1;

        // A move asserting a stale/way-off seq is rejected...
        $this->actingAs($player)
            ->postJson("/api/v1/matches/{$match->id}/move", [
                'color' => $color,
                'token' => 0,
                'action_id' => 'ooo-move-stale',
                'seq' => $expectedSeq - 1,
            ])
            ->assertStatus(422);

        // ...while the correctly-ordered move is accepted.
        $this->actingAs($player)
            ->postJson("/api/v1/matches/{$match->id}/move", [
                'color' => $color,
                'token' => 0,
                'action_id' => 'ooo-move-ok',
                'seq' => $expectedSeq,
            ])
            ->assertOk();

        $this->assertSame(
            1,
            MatchEvent::where('match_id', $match->id)->where('type', 'token_moved')->count(),
        );
    }
}
