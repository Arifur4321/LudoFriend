<?php

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Broadcast IMMEDIATELY (ShouldBroadcastNow) — see DiceRolled for why in-game
 * events must not depend on a queue worker to be delivered.
 */
class TurnChanged implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /** Authoritative post-commit state revision (match_state `seq`). */
    public ?int $revision = null;

    public function __construct(
        public int $matchId,
        public string $color,
    ) {
    }

    public function broadcastOn(): array
    {
        return [new PrivateChannel("match.{$this->matchId}")];
    }

    public function broadcastAs(): string
    {
        return 'game.turn_changed';
    }

    public function broadcastWith(): array
    {
        return [
            'match_id' => $this->matchId,
            'turn' => $this->color,
            'revision' => $this->revision,
        ];
    }
}
