import 'dart:async';
import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import '../../core/config/app_config.dart';
import '../../core/utils/logger.dart';

/// A realtime event delivered on a channel.
class RealtimeEvent {
  const RealtimeEvent(this.channel, this.event, this.data);
  final String channel;
  final String event;
  final Map<String, dynamic> data;
}

/// A clean WebSocket client that speaks the Pusher protocol, so it works
/// against Laravel Reverb, Soketi or laravel-websockets without a heavy plugin.
///
/// Features: connection handshake, (re)subscription, ping/pong keep-alive,
/// automatic reconnect with backoff, and — crucially for long online matches —
/// **liveness detection**. A mobile OS silently drops the TCP socket when the
/// app is backgrounded or the network switches; a plain client never notices
/// (no `onDone` fires), so `_connected` stays `true`, `connect()` early-returns
/// forever, and NO realtime events arrive. The match then limps along on the
/// client's 2s recovery poll, which is exactly what surfaces as "the dice needs
/// several taps", "the token tap does nothing", and "the turn is late". A
/// periodic client ping + a watchdog that reconnects when the server goes quiet
/// keep the socket honest, and [ensureConnected] lets the app force an immediate
/// re-check the moment it returns to the foreground.
class WebSocketService {
  WebSocketChannel? _channel;
  final StreamController<RealtimeEvent> _events =
      StreamController<RealtimeEvent>.broadcast();
  final StreamController<String> _connections =
      StreamController<String>.broadcast();
  final Map<String, String?> _subscriptions = {}; // channel -> auth (nullable)

  String? _socketId;
  bool _connected = false;
  bool _connecting = false;
  int _retry = 0;
  Timer? _reconnectTimer;
  bool _disposed = false;

  // ---- liveness -------------------------------------------------------------
  /// Wall-clock of the last frame received from the server (any frame, incl.
  /// pings/pongs). Used to detect a silently-dead ("zombie") socket.
  DateTime? _lastInboundAt;
  Timer? _heartbeatTimer;
  Timer? _watchdogTimer;

  /// How often we proactively ping so a quiet game (nobody moving) still proves
  /// the socket is alive.
  static const Duration _heartbeatInterval = Duration(seconds: 25);

  /// How often the watchdog checks liveness.
  static const Duration _watchdogInterval = Duration(seconds: 10);

  /// If no frame at all arrives within this window the socket is treated as
  /// dead and rebuilt. Comfortably larger than [_heartbeatInterval] so a single
  /// slow round-trip never triggers a needless reconnect.
  static const Duration _staleAfter = Duration(seconds: 40);

  Stream<RealtimeEvent> get events => _events.stream;
  Stream<String> get connections => _connections.stream;
  bool get isConnected => _connected;
  String? get socketId => _socketId;

  Uri _endpoint() {
    const scheme = AppConfig.wsTls ? 'wss' : 'ws';
    return Uri.parse(
      '$scheme://${AppConfig.wsHost}:${AppConfig.wsPort}/app/${AppConfig.wsKey}'
      '?protocol=7&client=ludo-friends&version=1.0.0',
    );
  }

  Future<void> connect() async {
    if (_disposed || _connected || _connecting) return;
    _connecting = true;
    try {
      final channel = WebSocketChannel.connect(_endpoint());
      _channel = channel;
      channel.stream.listen(
        _onMessage,
        onDone: _onDone,
        onError: _onError,
        cancelOnError: false,
      );
    } catch (e, st) {
      _connecting = false;
      AppLogger.e('WS connect failed', e, st);
      _scheduleReconnect();
    }
  }

  /// Re-establish the socket if it is down OR has silently gone stale (a zombie
  /// left over from the app being backgrounded / a network switch). Safe to
  /// call often: it no-ops while a healthy connection is live. The game
  /// controller calls this the instant the app resumes, so turns/dice/moves
  /// flow again immediately instead of only after the next recovery poll.
  Future<void> ensureConnected() async {
    if (_disposed) return;
    if (_connected) {
      if (_isStale()) {
        AppLogger.d('WS looks stale (resume/zombie) — forcing reconnect');
        _forceReconnect();
      }
      return;
    }
    if (_connecting) return;
    _reconnectTimer?.cancel();
    _retry = 0;
    await connect();
  }

  bool _isStale() =>
      _lastInboundAt == null ||
      DateTime.now().difference(_lastInboundAt!) > _staleAfter;

  void _onMessage(dynamic raw) {
    // Any frame — data event, ping, or pong — proves the socket is alive.
    _lastInboundAt = DateTime.now();

    Map<String, dynamic> msg;
    try {
      msg = jsonDecode(raw as String) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final event = msg['event'] as String? ?? '';
    final channel = msg['channel'] as String? ?? '';
    dynamic data = msg['data'];
    if (data is String && data.isNotEmpty) {
      try {
        data = jsonDecode(data);
      } catch (_) {
        // leave as raw string
      }
    }
    final dataMap = data is Map<String, dynamic> ? data : <String, dynamic>{};

    switch (event) {
      case 'pusher:connection_established':
        _socketId = dataMap['socket_id'] as String?;
        _connected = true;
        _connecting = false;
        _retry = 0;
        _startLiveness();
        AppLogger.d('WS connected (socket $_socketId)');
        if (_socketId != null) {
          // Private-channel auth signatures are tied to the socket id. The
          // realtime coordinator listens here and obtains fresh signatures
          // before resubscribing after every reconnect.
          _connections.add(_socketId!);
        }
        break;
      case 'pusher:ping':
        _send({'event': 'pusher:pong', 'data': {}});
        break;
      case 'pusher:pong':
        // Liveness already refreshed at the top of this handler.
        break;
      case 'pusher:error':
        AppLogger.e('WS pusher error: $dataMap');
        break;
      default:
        _events.add(RealtimeEvent(channel, event, dataMap));
    }
  }

  /// Start (or restart) the keep-alive ping and the zombie-socket watchdog.
  void _startLiveness() {
    _lastInboundAt = DateTime.now();
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(_heartbeatInterval, (_) {
      if (_connected) {
        _send({'event': 'pusher:ping', 'data': <String, dynamic>{}});
      }
    });
    _watchdogTimer?.cancel();
    _watchdogTimer = Timer.periodic(_watchdogInterval, (_) {
      if (_connected && _isStale()) {
        AppLogger.d('WS watchdog: server went quiet — reconnecting');
        _forceReconnect();
      }
    });
  }

  void _stopLiveness() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
    _watchdogTimer?.cancel();
    _watchdogTimer = null;
  }

  /// Tear down a (possibly zombie) socket and schedule a fresh connection.
  void _forceReconnect() {
    _connected = false;
    _connecting = false;
    _socketId = null;
    _stopLiveness();
    try {
      _channel?.sink.close();
    } catch (_) {
      // best effort — the socket may already be gone
    }
    _channel = null;
    if (!_disposed) _scheduleReconnect();
  }

  void _onDone() {
    _connected = false;
    _connecting = false;
    _socketId = null;
    _stopLiveness();
    if (!_disposed) _scheduleReconnect();
  }

  void _onError(Object error, StackTrace st) {
    AppLogger.e('WS stream error', error, st);
    _connected = false;
    _connecting = false;
    _socketId = null;
    _stopLiveness();
    if (!_disposed) _scheduleReconnect();
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _retry = (_retry + 1).clamp(1, 6);
    final delay = Duration(seconds: _retry * 2); // 2s, 4s ... capped at 12s
    AppLogger.d('WS reconnect in ${delay.inSeconds}s');
    _reconnectTimer = Timer(delay, connect);
  }

  /// Subscribe to [channel]. For private/presence channels, pass [auth] from
  /// the backend `/broadcasting/auth` response.
  Future<void> subscribe(String channel, {String? auth}) async {
    _subscriptions[channel] = auth;
    if (_connected) _sendSubscribe(channel, auth);
  }

  void _sendSubscribe(String channel, String? auth) {
    final data = <String, dynamic>{'channel': channel};
    if (auth != null) data['auth'] = auth;
    _send({'event': 'pusher:subscribe', 'data': data});
  }

  Future<void> unsubscribe(String channel) async {
    _subscriptions.remove(channel);
    _send({
      'event': 'pusher:unsubscribe',
      'data': {'channel': channel},
    });
  }

  void _send(Map<String, dynamic> message) {
    try {
      _channel?.sink.add(jsonEncode(message));
    } catch (e, st) {
      AppLogger.e('WS send failed', e, st);
    }
  }

  Future<void> disconnect() async {
    _reconnectTimer?.cancel();
    _stopLiveness();
    _subscriptions.clear();
    _connected = false;
    _connecting = false;
    _socketId = null;
    await _channel?.sink.close();
  }

  void dispose() {
    _disposed = true;
    _reconnectTimer?.cancel();
    _stopLiveness();
    _channel?.sink.close();
    _events.close();
    _connections.close();
  }
}

final webSocketServiceProvider = Provider<WebSocketService>((ref) {
  final service = WebSocketService();
  ref.onDispose(service.dispose);
  return service;
});
