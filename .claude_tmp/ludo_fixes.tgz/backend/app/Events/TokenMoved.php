<?php

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Broadcast IMMEDIATELY (ShouldBroadcastNow) — see DiceRolled for why in-game
 * events must not depend on a queue worker to be delivered.
 */
class TokenMoved implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Authoritative post-commit state revision (match_state `seq`). Stamped by
     * the engine just before flushing. Distinct from [sequence], which is the
     * token_moved event's own seq used to de-duplicate the walk animation.
     */
    public ?int $revision = null;

    /**
     * @param  int[]  $path
     * @param  array<int,array{color:string,token:int,from:int}>  $captured
     */
    public function __construct(
        public int $matchId,
        public string $color,
        public int $token,
        public int $from,
        public int $to,
        public array $path,
        public array $captured = [],
        public ?int $sequence = null,
    ) {}

    public function broadcastOn(): array
    {
        return [new PrivateChannel("match.{$this->matchId}")];
    }

    public function broadcastAs(): string
    {
        return 'game.token_moved';
    }

    public function broadcastWith(): array
    {
        return [
            'match_id' => $this->matchId,
            'color' => $this->color,
            'token' => $this->token,
            'from' => $this->from,
            'to' => $this->to,
            'path' => $this->path,
            'captured' => $this->captured,
            'move_seq' => $this->sequence,
            'revision' => $this->revision,
        ];
    }
}
