<?php

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Broadcast IMMEDIATELY (ShouldBroadcastNow) — see DiceRolled for why in-game
 * events must not depend on a queue worker to be delivered.
 */
class GameEnded implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /** Authoritative post-commit state revision (match_state `seq`). */
    public ?int $revision = null;

    public function __construct(
        public int $matchId,
        public string $winnerColor,
        public ?int $winnerUserId = null,
    ) {
    }

    public function broadcastOn(): array
    {
        return [new PrivateChannel("match.{$this->matchId}")];
    }

    public function broadcastAs(): string
    {
        return 'game.ended';
    }

    public function broadcastWith(): array
    {
        return [
            'match_id' => $this->matchId,
            'winner_color' => $this->winnerColor,
            'winner_user_id' => $this->winnerUserId,
            'revision' => $this->revision,
        ];
    }
}
