<?php

namespace App\Events;

use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Broadcast IMMEDIATELY (ShouldBroadcastNow), not via the queue.
 *
 * In-game events must reach the opponent the instant the action commits. With
 * the default `ShouldBroadcast` they are pushed onto the configured queue
 * (QUEUE_CONNECTION=database in this app) and only delivered once a
 * `queue:work` worker picks them up — so a missing, slow, or backed-up worker
 * silently degrades every match to the client's 2s recovery poll (the "dice
 * needs several taps / token tap does nothing / turn is late" reports). Sending
 * now removes that dependency; ordering is still safe because the engine
 * flushes these only AFTER the DB transaction commits.
 */
class DiceRolled implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Authoritative post-commit state revision (match_state `seq`). Stamped by
     * the engine just before flushing so a client can order this event against
     * its applied snapshot and resync to exactly this revision.
     */
    public ?int $revision = null;

    public function __construct(
        public int $matchId,
        public string $color,
        public int $dice,
        public bool $forfeited = false,
    ) {
    }

    public function broadcastOn(): array
    {
        return [new PrivateChannel("match.{$this->matchId}")];
    }

    public function broadcastAs(): string
    {
        return 'game.dice_rolled';
    }

    public function broadcastWith(): array
    {
        return [
            'match_id' => $this->matchId,
            'color' => $this->color,
            'dice' => $this->dice,
            'forfeited' => $this->forfeited,
            'revision' => $this->revision,
        ];
    }
}
